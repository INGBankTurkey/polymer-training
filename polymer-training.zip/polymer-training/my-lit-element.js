import {LitElement, html} from '@polymer/lit-element/lit-element.js';

class MyLitElement extends LitElement{
    constructor(){
        super();
        addEventListener('click', this.addTree.bind(this));
    }

    static get properties(){
        return {
            trees: Number
        }
    }

    _render({trees}){
        return html`
        <div># of trees:${trees}</div>
        <slot></slot>
        `;
    }

    addTree(){
        this.trees++;
    }
}

customElements.define('my-lit-element', MyLitElement);