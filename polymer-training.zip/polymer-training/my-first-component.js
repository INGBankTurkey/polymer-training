import {PolymerElement, html} from '@polymer/polymer/polymer-element.js';

import IronAjax from '@polymer/iron-ajax/iron-ajax.js';

class MyFirstComponent extends PolymerElement{
    constructor(){
        super();
        addEventListener('click', this.changeMessage.bind(this));
    }

    static get properties(){
        return {
            message : String,
            repos: {
             type: Array
            }
        }
    }

    static get template(){
        return html`
        <style>
            h1{
                background: var(--my-component-background);
            }
        </style>
        <h1>[[message]]</h1>
        <iron-ajax
            auto
            url="https://api.github.com/users/burczu/repos";
            params='{"type": "all"}'
            handle-as="json"
            on-response="handleResponse"></iron-ajax>
        `;
    }

    changeMessage(){
        this.message = 'I clicked!!!';
    }
    
    handleResponse(data){
        
    }
}

customElements.define('my-first-component', MyFirstComponent);